from django.db import models

# Create your models here.

class Conductor(models.Model):
    nombre = models.CharField(max_length=100)
    licencia_conducir = models.CharField(max_length=50)
    telefono = models.CharField(max_length=20)
    direccion = models.CharField(max_length=255)

    def __str__(self):
        return self.nombre

class Camion(models.Model):
    placa = models.CharField(max_length=20)
    modelo = models.CharField(max_length=50)
    capacidad_carga = models.FloatField()
    conductor = models.ForeignKey(Conductor, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.placa} - {self.modelo}"

class Cliente(models.Model):
    nombre_empresa = models.CharField(max_length=100)
    direccion = models.CharField(max_length=255)
    telefono = models.CharField(max_length=20)
    correo_electronico = models.EmailField()

    def __str__(self):
        return self.nombre_empresa

class TipoMadera(models.Model):
    nombre = models.CharField(max_length=50)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre

class Carga(models.Model):
    tipo_madera = models.ForeignKey(TipoMadera, on_delete=models.CASCADE)
    cantidad = models.FloatField() 
    peso = models.FloatField()  
    camion = models.ForeignKey(Camion, on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)

    def __str__(self):
        return f"Carga de {self.tipo_madera} - {self.cantidad}m³"