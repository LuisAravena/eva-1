from django.contrib import admin
from .models import Conductor, Camion, Cliente, TipoMadera, Carga

# Register your models here.
admin.site.register(Conductor)
admin.site.register(Camion)
admin.site.register(Cliente)
admin.site.register(TipoMadera)
admin.site.register(Carga)